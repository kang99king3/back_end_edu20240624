// HomePage.js
import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import Header from '../components/layouts/Header';
import Sidebar from '../components/layouts/Sidebar';
import MainContent from '../components/layouts/MainContent';
import Footer from '../components/layouts/Footer';

const HomePage = ({isAuthenticated,setIsAuthenticated}) => {

    //로그인 id가 저장되어 있는 localStorage에서 가져오기
    const loginId=localStorage.getItem("id");
    
    return (
        <>
             <div className="app">
                <Header id={loginId} isAuthenticated={isAuthenticated} setIsAuthenticated={setIsAuthenticated}/>
                <div className="content">
                    <Sidebar />
                    <MainContent id={loginId} />
                </div>
                <Footer />
            </div>
            
        </>
    );
};

export default HomePage;