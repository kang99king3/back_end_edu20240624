import React, { useEffect, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { getBoardList } from '../../services/BoardService';


const BoardList = () => {

    const [boardList,setBoardList]=useState([]);//글목록 상태 관리
    const [isAllChecked, setIsAllChecked] = useState(false); // 전체 체크 상태 관리
    const [checkedItems, setCheckedItems] = useState([]); // 개별 체크 상태 관리

    const navigate=useNavigate();

    useEffect(()=>{
        // const response = getBoardList();
        // console.log("a")
        // setBoardList(response.data['list']);
        response();
    },[]);

    const response = async () =>{
       let result= await getBoardList();
       if(result){
           setBoardList(result.data.list);
           console.log(result.data.list);
       }else{
            navigate('/login');
       }
    //    setBoardList((await getBoardList()).data.list) ;
    }
    
    //전체 체크-해제를 위한 함수
    const allChk = (checked) => {
        setIsAllChecked(checked);//전체 체크 상태 업데이트
        if(checked){
            //체크된 경우라면 체크될 목록들의 seq값들을 저장한다.
            setCheckedItems(boardList.map((dto)=>dto.board_seq))
        }else{
            //체크가 안된 경우면 목록 초기화
            setCheckedItems([]);
        }

    }

    //체크박스 체크상태 변경시 업데이트 실행 --> 이걸 설정해야 실제 체크했을때 체크,해제가 표현됨
    const handleCheckboxChange = (checked, value) => {
        if (checked) {
            setCheckedItems([...checkedItems, value]); // 선택된 항목 추가
        } else {
            setCheckedItems(checkedItems.filter((item) => item !== value)); // 선택된 항목 제거
        }
    };

    return (
        <div className='table-container'>
            <table className='custom-table'>
                <thead>
                    <tr>
                        <th><input type="checkbox" name="allchk" checked={isAllChecked} onChange={(e)=>{allChk(e.target.checked)}} /></th>
                        <th>번호</th>
                        <th>작성자</th>
                        <th>제목</th>
                        <th>작성일</th>
                    </tr>
                </thead>
                <tbody>
                    {boardList.map(dto=>
                                <tr key={dto.board_seq}>
                                    <td><input type="checkbox" 
                                               name="seqs" 
                                               value={dto.board_seq}
                                               checked={checkedItems.includes(dto.board_seq)}
                                               onChange={(e)=>handleCheckboxChange(e.target.checked,dto.board_seq)}
                                               /></td>
                                    <td>{dto.board_seq}</td>
                                    <td>{dto.id}</td>
                                    <td><Link to={`/board/detail/${dto.board_seq}`}>{dto.title}</Link></td>
                                    <td>{dto.regdate}</td>
                                </tr>
                    )}
                <tr>
                    <td colSpan={5}>
                        <Link to={'/board/boardinsert'}><input className='button' type="button" value="글쓰기"/></Link>&nbsp;&nbsp;&nbsp;
                        <input className='button' type="submit" value="삭제"/>
                    </td>
                </tr>
                </tbody>
            </table>
        </div>
    );
};

export default BoardList;