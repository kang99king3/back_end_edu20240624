import React, { useEffect, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { deleteBoard, getBoardList } from '../../services/BoardService';

const BoardList = () => {
    const [boardList, setBoardList] = useState([]); // 글 목록
    const [currentPage, setCurrentPage] = useState(1); // 현재 페이지
    const [itemsPerPage] = useState(10); // 페이지당 항목 수
    const navigate = useNavigate();

    // 전체 체크박스 상태 관리
    const [isAllChecked, setIsAllChecked] = useState(false);
    const [checkedItems, setCheckedItems] = useState([]);

    useEffect(() => {
        response();
    }, []);

    const response = async () => {
        let result = await getBoardList();
        if (result) {
            setBoardList(result.data.list);
        } else {
            navigate('/login');
        }
    };

    // 전체 페이지 수 계산
    const totalPages = Math.ceil(boardList.length / itemsPerPage);

    // 현재 페이지에 표시할 데이터
    const currentData = boardList.slice(
        (currentPage - 1) * itemsPerPage,
        currentPage * itemsPerPage
    );

    // 전체 체크 상태 변경
    const allChk = (checked) => {
        setIsAllChecked(checked);
        if (checked) {
            setCheckedItems(currentData.map((dto) => dto.board_seq));
        } else {
            setCheckedItems([]);
        }
    };

    // 개별 체크 상태 변경
    const handleCheckboxChange = (checked, value) => {
        if (checked) {
            setCheckedItems([...checkedItems, value]);
        } else {
            setCheckedItems(checkedItems.filter((item) => item !== value));
        }
    };

    // 페이지 변경
    const handlePageChange = (page) => {
        setCurrentPage(page);
        setIsAllChecked(false); // 페이지 이동 시 전체 체크 해제
        setCheckedItems([]); // 선택 초기화
    };

    //여러글 삭제
    const deleteHandler = (e) =>{
        e.preventDefault();
        if(window.confirm("정말 삭제하시겠습니까?")){
            console.log(e.target.seqs[0].checked);
            const chks=Array.from(e.target.seqs);

            const checkedItems=chks.filter(items => items.checked);

            const seqs = checkedItems.map(items => items.value);
           
            console.log(seqs);
            if(seqs.length!==0){
                deleteBoard(seqs).then(res=>{
                    if(res.status===201){
                        alert(res.data);
                        response();//글을 삭제하고 글목록을 다시 요청한다.
                    }
                })
            }else{
                console.log("최소 하나 이상 체크해야 됩니다.")
            }
        }
    }

    return (
        <div className='table-container'>
            <form onSubmit={deleteHandler} >
                <table className='custom-table'>
                    <thead>
                        <tr>
                            <th>
                                <input
                                    type="checkbox"
                                    name="allchk"
                                    checked={isAllChecked}
                                    onChange={(e) => allChk(e.target.checked)}
                                />
                            </th>
                            <th>번호</th>
                            <th>작성자</th>
                            <th>제목</th>
                            <th>작성일</th>
                        </tr>
                    </thead>
                    <tbody>
                        {currentData.map((dto) => (
                            <tr key={dto.board_seq}>
                                <td>
                                    <input
                                        type="checkbox"
                                        name="seqs"
                                        value={dto.board_seq}
                                        checked={checkedItems.includes(dto.board_seq)}
                                        onChange={(e) =>
                                            handleCheckboxChange(e.target.checked, dto.board_seq)
                                        }
                                    />
                                </td>
                                <td>{dto.board_seq}</td>
                                <td>{dto.id}</td>
                                <td>
                                    <Link to={`/board/detail/${dto.board_seq}`}>
                                        {dto.title}
                                    </Link>
                                </td>
                                <td>{dto.regdate}</td>
                            </tr>
                        ))}
                        <tr>
                            <td colSpan={5}>
                                <Link to={'/board/boardinsert'}>
                                    <input className='button' type="button" value="글쓰기" />
                                </Link>
                                &nbsp;&nbsp;&nbsp;
                                <input className='button' type="submit" value="삭제" />
                            </td>
                        </tr>
                    </tbody>
                </table>
            </form>        
            {/* 페이징 버튼 */}
            <div className="pagination">
                {Array.from({ length: totalPages }, (_, index) => index + 1).map((page) => (
                    <button
                        key={page}
                        onClick={() => handlePageChange(page)}
                        disabled={currentPage === page}
                    >
                        {page}
                    </button>
                ))}
            </div>
        </div>
    );
};

export default BoardList;