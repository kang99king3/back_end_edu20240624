// LoginPage.js
import React, { useState } from 'react';
import { login } from '../services/MemberService';
import { useNavigate } from 'react-router-dom';

const LoginPage = ({isAuthenticated,setIsAuthenticated}) => {
    const [id, setId] = useState('hk');
    const [password, setPassword] = useState('12345678');
    const [error, setError] = useState('');

    const navigate=useNavigate();

    // 로그인 요청을 처리하는 함수
    const handleLogin = async (event) => {
        event.preventDefault();

        try {
            const response = await login({'id':id,'password':password});

            if(response.data===null || response.data === undefined){
                console.log("1:"+response.data);
                throw new Error("로그인실패");

            }

            console.log(response.status);

            // 로그인 성공 시 토큰을 로컬 스토리지에 저장
            localStorage.setItem('id', response.data['id']);
            setIsAuthenticated(true);
            
            // 로그인 후 페이지 이동 (예: 홈 페이지)
            // window.location.href = '/';

            if(response.status === 200){
                navigate("/");
            }
        } catch (err) {
            setError('로그인에 실패했습니다. 이메일과 비밀번호를 확인하세요.');
        }
    };

    return (
            <div style={styles.container}>
                <h2>로그인</h2>
                <form onSubmit={handleLogin} style={styles.form}>
                    <div style={styles.inputGroup}>
                        <label>아이디</label>
                        <input
                            type="text"
                            value={id}
                            onChange={(e) => setId(e.target.value)}
                            required
                            style={styles.input}
                        />
                    </div>
                    <div style={styles.inputGroup}>
                        <label>비밀번호</label>
                        <input
                            type="password"
                            value={password}
                            onChange={(e) => setPassword(e.target.value)}
                            required
                            style={styles.input}
                        />
                    </div>
                    {error && <p style={styles.error}>{error}</p>}
                    <button type="submit" style={styles.button}>로그인</button>
                </form>
            </div>
    );
};

const styles = {
    container: {
        maxWidth: '400px',
        margin: '200px auto',
        padding: '20px',
        textAlign: 'center',
        border: '1px solid #ccc',
        borderRadius: '5px',
        boxShadow: '0 4px 8px rgba(0, 0, 0, 0.1)',
    },
    form: {
        display: 'flex',
        flexDirection: 'column',
    },
    inputGroup: {
        marginBottom: '15px',
        textAlign: 'left',
    },
    input: {
        width: '100%',
        padding: '8px',
        borderRadius: '4px',
        border: '1px solid #ddd',
    },
    button: {
        padding: '10px',
        borderRadius: '4px',
        border: 'none',
        backgroundColor: 'black',
        color: 'white',
        fontSize: '16px',
        cursor: 'pointer',
    },
    error: {
        color: 'red',
        fontSize: '14px',
        marginBottom: '10px',
    },

};

export default LoginPage;