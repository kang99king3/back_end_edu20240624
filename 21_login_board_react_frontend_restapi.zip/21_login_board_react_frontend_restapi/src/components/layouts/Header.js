import React from 'react';
import '../../assets/Header.css';
import { useNavigate } from 'react-router-dom';
import { logOut } from '../../services/MemberService';


function Header({id,isAuthenticated,setIsAuthenticated}) {
  
    const navigate=useNavigate();

     const handleLogout = async () => {
        localStorage.removeItem('id');
        setIsAuthenticated(false);
        logOut();
        navigate("/");
      };

    console.log(isAuthenticated);

    return (
      <header className="header">
        <h1>My Website</h1>
        <nav>
          <a href="/home">Home</a>
          <a href="#about">About</a>
          <a href="#contact">Contact</a>
          {isAuthenticated ? <span>{id}님이 로그인하였습니다. <button className='button' onClick={handleLogout}>Logout</button></span>
                            :<span><button className='button' onClick={()=>{navigate('/login')}}>로그인</button></span>}
        </nav>
      </header>
    );
  }
  
  export default Header;