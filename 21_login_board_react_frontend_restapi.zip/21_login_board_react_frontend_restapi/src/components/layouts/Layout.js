import React from 'react';
import Header from './Header';
import Sidebar from './Sidebar';
import Footer from './Footer';
import { Outlet } from 'react-router-dom';
import '../../assets/layout.css';

const Layout = ({isAuthenticated,setIsAuthenticated}) => {

     //로그인 id가 저장되어 있는 localStorage에서 가져오기
     const loginId=localStorage.getItem("id");

    return (
        <>
            <div className="app">
                <Header id={loginId} isAuthenticated={isAuthenticated} setIsAuthenticated={setIsAuthenticated}/>
                <main className="content">
                    <Sidebar />
                    {/* <MainContent id={loginId} /> */}
                    <Outlet id={loginId}/>
                </main>
                <Footer />
            </div>
            
        </>
    );
};

export default Layout;