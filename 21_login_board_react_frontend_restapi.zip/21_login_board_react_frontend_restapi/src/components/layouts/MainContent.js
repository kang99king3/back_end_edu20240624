import React from 'react';

import { Link } from 'react-router-dom';

function MainContent(props) {

    // const id=props.id;
    
    return (
    <main className="main-content">
        <div>
            <h1>홈 페이지</h1>
            {/* <p>{id}님이 로그인하였습니다.</p> */}
            
        </div>
    </main>
  );
}

export default MainContent;