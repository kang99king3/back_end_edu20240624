import axios from 'axios';
import React from 'react';


const apiURL="http://localhost:9090";

const instance = axios.create({
    baseURL:apiURL,
    headers:{"Content-Type":"application/json"},
    withCredentials:true, //jsessionid 쿠키값 포함하여 전송
});

// const accessInstance = axios.create({
//     baseURL: apiURL,
//     headers: {
//       "Content-Type": "application/json",
//     },
//   });

export const getBoardList = async () => {
    // const response1 = await instance.get(`/products/?page=${pageParams}`);
    
    // const response = await instance.post('/user/login',null, {"id":"hk","password":"12345678"});
    let response=null;
    try {
        response = await instance.get('/board/boardlist',
                                            // {withCredentials:true} //쿠키를 포함하여 전송
                                            );
    } catch (error) {
       console.log(response); 
    }
    
    return response;
  };
 
export const getBoardDetail = (seq) => {
    // const response1 = await instance.get(`/products/?page=${pageParams}`);

    // const response = await instance.post('/user/login',null, {"id":"hk","password":"12345678"});
    let response=null;
    try {
        response = instance.get('/board/boarddetail/'+seq,
                                            // {withCredentials:true} //쿠키를 포함하여 전송
                                            );
    } catch (error) {
        console.log(response); 
    }

    return response;
};

export const updateBoard = async (board) => {
   
    let response=null;
    try {
        response = await instance.put('/board/boardupdate',{
                                                            title:board.title,
                                                            content:board.content,
                                                            board_seq:board.board_seq
                                                            } 
                                     );
                                  
                                           
    } catch (error) {
        console.error(error.response || error.message); // 오류 디버깅
    }
    
    return response;
};

export const deleteBoard = async (board_seq) => {
   
    let response=null;
    try {
        response = await instance.delete('/board/muldel',{
            params:{seqs:board_seq.join(',')},
        });
        //response = await instance.put('/board/muldel?seq='+board_seq);                          
                                           
    } catch (error) {
        //console.error(error.response || error.message); // 오류 디버깅
        console.error(error.message);
    }
    
    return response;
};

export const insertBoard = async (board) => {
   
    let response=null;
    try {
        response = await instance.post('/board/boardinsert',board,{
                                                                        headers:{
                                                                            "Content-Type": "multipart/form-data",
                                                                        }
                                                                    }
        );
        //response = await instance.put('/board/muldel?seq='+board_seq);                          
                                           
    } catch (error) {
        //console.error(error.response || error.message); // 오류 디버깅
        console.error(error.message);
    }
    
    return response;
};