import { Navigate } from "react-router-dom";

const PrivateRoute = ({isAuthenticated,isLoading,children}) => {
    console.log("PrivateRoute");
    if (isLoading) return null; // 로딩 중에는 아무것도 렌더링하지 않음
    return isAuthenticated ? children : <Navigate to="/login" />;
  };

export default PrivateRoute;