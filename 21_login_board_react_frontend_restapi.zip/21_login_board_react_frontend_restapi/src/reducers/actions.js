// actions/authActions.js
export const loginUser = (userData) => {
    return {
        type: 'auth/login', // 'auth/login' 액션 타입
        payload: userData,  // 사용자 데이터
    };
};

export const logoutUser = () => {
    return {
        type: 'auth/logout', // 로그아웃 액션
    };
};