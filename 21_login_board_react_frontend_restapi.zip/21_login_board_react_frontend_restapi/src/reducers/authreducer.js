// reducers/authReducer.js
const initialState = {
    isAuthenticated: false,
    user: null,
};

const authReducer = (state = initialState, action) => {
    switch (action.type) {
        case 'auth/login':  // 로그인 성공 시
            return {
                ...state,
                isAuthenticated: true,
                user: action.payload,
            };
        case 'auth/logout':  // 로그아웃 시
            return {
                ...state,
                isAuthenticated: false,
                user: null,
            };
        default:
            return state;
    }
};

export default authReducer;